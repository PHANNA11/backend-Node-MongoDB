
const { MongoClient } = require("mongodb");
const url = "mongodb+srv://dbUser:user1234@user.bba2jtt.mongodb.net/?retryWrites=true&w=majority";
const client = new MongoClient(url);
//===== database =======
const dbName = "flutter";
async function getData() {
    let result = await client.connect();
    db = result.db(dbName);
    collection = db.Collection('cours');
    let data = await collection.find({}).toArray();
    console.log(data);
}
getData();