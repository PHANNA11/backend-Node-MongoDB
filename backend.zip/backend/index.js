const express = require("express");
const fs = require("fs/promises");
const mongoose = require("mongoose");
const route = require("./routes/course-route");
const port = process.env.port || 4000;
// ====== Swagger - ui -  ====
const swaggerJsDoc = require("swagger-jsdoc");
const swaggerUi = require("swagger-ui-express");
const { schema } = require("./model/courseModel");
const { array } = require("joi");

const app = express();
app.use(express.json());

const options = {
    swaggerDefinition: {
        info: {
            title: 'Online Course API',
            versioin: '1.0.0'
        },
        schemes: [{
            type: String,
            method: "//localhost:4000/api-docs",

        }]


    },
    servers: [{
        url: "http://localhost:4000"

    }],

    apis: ['./index.js'],
};
const swaggerDoc = swaggerJsDoc(options);

app.use("/api-docs", swaggerUi.serve, swaggerUi.setup(swaggerDoc));
/**
 * @swagger
 * /:
 *  get:
 *    summary: course
 *    respones:
 *      200:
 *      description: success respone 
 */
/**
 * @swagger
 * /:
 *  post:
 *      summary: course / CourseModel
 *      respones:
 *          201:
 *              description: data insert success
 */
//========== Put ========
/**
 * @swagger
 * /:
 *  put:
 *      summary: course / courseModel / {id}
 */
// ======== DELETE ========
/**
 * @swagger
 * /:
 *  delete:
 *      summary: course / {id}
 */
console.log(swaggerDoc);

app.use("/course", route);
async function ConnectingDB() {
    try {
        await mongoose.connect('mongodb+srv://dbUser:MSjnQrRCyB67nJs1@user.bba2jtt.mongodb.net/?retryWrites=true&w=majority').then(() => {
            console.log("MongoDB Connect success...!!");
        });
    } catch (error) {
        console.log('Error Connection....');
    }
}
ConnectingDB();
app.listen(port, () => {
    console.log('Connecting.... Port: ' + port);
});
// mongoose.connect('mongodb+srv://userAdmin:eLOqyG4XUt8RN9AA@cluster0.xph0dp9.mongodb.net/?retryWrites=true&w=majority').then(() => {
//     app.listen(port, () => {
//         console.log('Connecting.... Port: ' + port);
//     });
// }).catch(() => {
//     console.log('Error Connection....');
// });







