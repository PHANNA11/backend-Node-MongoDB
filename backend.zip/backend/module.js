const fs = require("fs");
const path = require("path");
function getFilePath() {
    return path.join(process.cwd(), "/data/file.txt");
}
function writeToFile(filePath, string) {
    // fs.writeFileSync(filePath, string);
    fs.appendFileSync(filePath, string);
}
function readFromFile(filePath) {
    return fs.readFileSync(filePath).toString();
}
exports.getFilePath = getFilePath;
exports.writeToFile = writeToFile;
exports.readFromFile = readFromFile;