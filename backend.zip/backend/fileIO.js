
const modules = require("./module");
modules.writeToFile(modules.getFilePath(), "I loce you\n")
console.log(modules.readFromFile(modules.getFilePath()));