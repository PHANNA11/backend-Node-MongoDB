//const { Double } = require("mongodb");
const mongoose = require("mongoose");

const schema = new mongoose.Schema({
    courseName: {
        type: String,
    },
    price: {
        type: String,
    }
});
module.exports = mongoose.model("courseModels", schema);