const express = require("express");
const { getAllCourse, addCourse, updateCourse, deleteCourse } = require("../controller/course-controller");
//const { findOne } = require("../model/courseModel");
const router = express.Router();
router.get('/', getAllCourse);
router.post('/', addCourse);
router.put('/:id', updateCourse);
router.delete('/:id', deleteCourse);
module.exports = router; 