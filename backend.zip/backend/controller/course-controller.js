const Course = require("../model/courseModel");
//====== GET =============
const getAllCourse = async (req, res, next) => {
    let course;
    try {
        course = await Course.find();
    } catch (error) {
        return next(err);
    }
    if (!course) {
        return res.status(500).json({ message: "Internal Server Error" });
    }
    return res.status(201).json({ course });
};

//======= POST ========
const addCourse = async (req, res, next) => {
    const { courseName, price } = req.body;
    if (!courseName && courseName.trim() === "" && !price && price.trim() === "") {
        return res.status(422).json({ message: "Invalid data...!!" });
    }
    let course;
    try {
        course = new Course({
            courseName, price,
        });
        course = await course.save();

    } catch (error) {
        return next(error);
    }
    if (!course) {
        return res.status(500).json({ message: "Unnable to save data...!!" });
    }
    return res.status(201).json({ course });

}
//========== PUT/UPDATE =========
const updateCourse = async (req, res, next) => {
    const id = req.params.id;
    const { courseName, price } = req.body;
    if (!courseName && courseName.trim() === "" && !price && price.trim() === "") {
        return res.status(422).json({ message: "Invalid data...!!" });
    }
    try {
        course = await Course.findByIdAndUpdate(id, { courseName, price });
    } catch (error) {
        return next(error);
    }
    if (!course) {
        return res.status(500).json({ message: "Unnable to save data...!!" });
    }
    return res.status(200).json({ message: "Update Success..!!" });
}
// ======== DELETE ========
const deleteCourse = async (req, res, next) => {
    const id = req.params.id;
    let course;
    try {
        course = await Course.findByIdAndDelete(id);
    } catch (error) {
        return next(error);
    }
    if (!course) {
        res.status(500).json({ message: "Unable to delete..!!!" });
    }
    return res.status(200).json({ message: "delete Success...!!!" });
}

exports.addCourse = addCourse;

exports.getAllCourse = getAllCourse;
exports.updateCourse = updateCourse;
exports.deleteCourse = deleteCourse;
